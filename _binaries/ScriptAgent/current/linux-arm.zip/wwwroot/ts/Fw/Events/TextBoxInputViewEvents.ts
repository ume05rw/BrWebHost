﻿/// <reference path="../../../lib/jquery/index.d.ts" />
/// <reference path="../../../lib/underscore/index.d.ts" />
/// <reference path="InputViewEvents.ts" />

namespace Fw.Events {
    export class TextBoxInputViewEventsClass extends InputViewEventsClass {
    }
    export const TextBoxInputViewEvents: TextBoxInputViewEventsClass = new TextBoxInputViewEventsClass();
}
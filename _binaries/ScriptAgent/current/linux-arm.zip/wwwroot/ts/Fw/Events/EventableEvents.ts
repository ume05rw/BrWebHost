/// <reference path="../../../lib/jquery/index.d.ts" />
/// <reference path="../../../lib/underscore/index.d.ts" />

namespace Fw.Events {
    export class EventableEventsClass {
    }

    export const EventableEvents: EventableEventsClass = new EventableEventsClass();
}

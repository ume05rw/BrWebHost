﻿/// <reference path="../../../lib/jquery/index.d.ts" />
/// <reference path="../../../lib/underscore/index.d.ts" />
/// <reference path="ControlViewEvents.ts" />

namespace Fw.Events {
    export class ButtonViewEventsClass extends ControlViewEventsClass {
    }
    export const ButtonViewEvents: ButtonViewEventsClass = new ButtonViewEventsClass();
}
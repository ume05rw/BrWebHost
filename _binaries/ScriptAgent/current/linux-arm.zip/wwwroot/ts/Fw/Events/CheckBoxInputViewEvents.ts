/// <reference path="../../../lib/jquery/index.d.ts" />
/// <reference path="../../../lib/underscore/index.d.ts" />
/// <reference path="InputViewEvents.ts" />

namespace Fw.Events {
    export class CheckBoxInputViewEventsClass extends InputViewEventsClass {
    }
    export const CheckBoxInputViewEvents: CheckBoxInputViewEventsClass = new CheckBoxInputViewEventsClass();
}

﻿/// <reference path="../../../lib/jquery/index.d.ts" />
/// <reference path="../../../lib/underscore/index.d.ts" />
/// <reference path="ButtonViewEvents.ts" />

namespace Fw.Events {
    export class RelocatableViewEventsClass extends ButtonViewEventsClass {
    }
    export const RelocatableViewEvents: RelocatableViewEventsClass = new RelocatableViewEventsClass();
}
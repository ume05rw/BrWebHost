/// <reference path="../../../lib/jquery/index.d.ts" />
/// <reference path="../../../lib/underscore/index.d.ts" />

namespace App.Items {
    export const enum ChartType {
        Hourly = 1,
        Daily = 2,
    }
}

/// <reference path="../../../lib/jquery/index.d.ts" />
/// <reference path="../../../lib/underscore/index.d.ts" />

namespace App.Items {
    export const enum ValidationFailType {
        Error = 1,
        Warning = 2
    }
}

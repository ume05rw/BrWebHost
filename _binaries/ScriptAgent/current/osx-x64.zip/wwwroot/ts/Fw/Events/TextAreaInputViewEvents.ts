﻿/// <reference path="../../../lib/jquery/index.d.ts" />
/// <reference path="../../../lib/underscore/index.d.ts" />
/// <reference path="InputViewEvents.ts" />

namespace Fw.Events {
    export class TextAreaInputViewEventsClass extends InputViewEventsClass {
    }
    export const TextAreaInputViewEvents: TextAreaInputViewEventsClass = new TextAreaInputViewEventsClass();
}
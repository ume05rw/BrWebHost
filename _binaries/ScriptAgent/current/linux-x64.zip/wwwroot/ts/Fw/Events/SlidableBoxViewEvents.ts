﻿/// <reference path="../../../lib/jquery/index.d.ts" />
/// <reference path="../../../lib/underscore/index.d.ts" />
/// <reference path="BoxViewEvents.ts" />

namespace Fw.Events {
    export class SlidableBoxViewEventsClass extends BoxViewEventsClass {
    }
    export const SlidableBoxViewEvents: SlidableBoxViewEventsClass = new SlidableBoxViewEventsClass();
}
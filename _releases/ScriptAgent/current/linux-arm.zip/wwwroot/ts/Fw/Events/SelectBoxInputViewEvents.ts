﻿/// <reference path="../../../lib/jquery/index.d.ts" />
/// <reference path="../../../lib/underscore/index.d.ts" />
/// <reference path="InputViewEvents.ts" />

namespace Fw.Events {
    export class SelectBoxInputViewEventsClass extends InputViewEventsClass {
    }
    export const SelectBoxInputViewEvents: SelectBoxInputViewEventsClass = new SelectBoxInputViewEventsClass();
}